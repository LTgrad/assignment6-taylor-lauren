<style type="text/css">

* {
margin: 0;
padding: 0;
border: 0;
}

header {
  background-color: green;
  padding: 20px;
  text-align: center;
}

header ul li {
  display: inline;
  padding: 40px;
  font-family: sans-serif;
}

nav a {
  text-decoration: none;
  color: white;
}

Footer {
  background-color: green;
  padding: 20px;
  text-align: center;
  font-family: sans-serif;
  color: white;
  margin: 5px auto;
}
</style>
  <header>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Music</a></li>
        <li><a href="#">Contact Us</a></li>
      </ul>
    </nav>
  </header>
  <body>
    <div class="container">
      <h1>Hello</h1>
        <p>Form processor by <a href="http://www.inventpartners.com">Invent Partners Web Design York</a>.</p>
    </div>
    <footer>
      <p>website by wala</p>
    </footer>
