<style type="text/css">

* {
margin: 0;
padding: 0;
border: 0;
}

header {
  background-color: green;
  padding: 20px;
  text-align: center;
}

header ul li {
  display: inline;
  padding: 40px;
  font-family: sans-serif;
}

nav a {
  text-decoration: none;
  color: white;
}

Footer {
  background-color: green;
  padding: 20px;
  text-align: center;
  font-family: sans-serif;
  color: white;
  margin: 5px auto;
}
</style>
  <header>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Music</a></li>
        <li><a href="#">Contact Us</a></li>
      </ul>
    </nav>
  </header>
  <body>
    <div class="container">
      <h1>Thank you for your enquiry</h1>
        <p>Thanks for your interest. we have received your message, and we will be in touch shortly.</p>
        <p>Form processor provided by <a href="http://www.inventpartners.com">Invent Partners web design York</a>.</p>
    </div>
  <footer>
    <p>website by wala</p>
  </footer>
